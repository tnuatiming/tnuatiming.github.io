## DESCRIPTION

Takes CSV or tab-delimited data from Excel and converts it into several web-friendly formats, include JSON and XML.
View it in action here: http://shancarter.github.com/mr-data-converter/
