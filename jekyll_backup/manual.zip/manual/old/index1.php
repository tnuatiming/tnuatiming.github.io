<?php include("/home/raz/public_html/password_protect.php"); ?>
<!DOCTYPE html>
<html class="no-js" lang="he" xml:lang="he" dir="rtl">

    <head>

        <!-- META -->
       <meta charset="utf-8">
        <title>תנועה מדידת זמנים &middot; הוראות הפעלה</title>
                <meta name="description" content="הוראות הפעלה למערכת מדידת הזמנים" />



        <meta name="viewport" content="width=device-width">
<link rel="apple-touch-icon-precomposed" href="/favicon-152.png">
        <link rel="apple-touch-icon" href="/apple-touch-icon.png"/>
        <meta name="msapplication-TileColor" content="#ffcc33">
        <meta name="msapplication-TileImage" content="/favicon-144.png">        <link rel="shortcut icon" href="../favicon.ico" sizes="16x16 32x32 48x48 64x64 128x128" type="image/x-icon" />
        <meta name="google-site-verification" content="fksQzLHsNNdUr7KUw53_2thUPno2gvM0oe_MRxWvjSo" />
<!-- iframe height adjust -->   <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.10.1/jquery.min.js"></script>

 <script>

    $(function(){
    var height = window.innerHeight;
    $('iframe').css('height', height);
});

//And if the outer div has no set specific height set..
$(window).resize(function(){
    var height = window.innerHeight;
    $('iframe').css('height', height);
});

    </script>
<style>
iframe {
  width: 100%;
  margin: 0;
  border: none;
  direction: rtl;
}
</style>


    </head>

    <body>
    <div class="content">
<iframe src="https://docs.google.com/document/d/1bu4bg4RvpHuWpfQSaURPV5OBA8WmNzGR9HReH6eSanE/pub?embedded=true"></iframe>
 </div>
 </body>
</html>
