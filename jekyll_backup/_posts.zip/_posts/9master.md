---
layout: post
tag: "אנדורו"
# אול מאונטיין, באחה, באחה ישראל, אנדורו, ג'ימקאנה, קארטינג, מוטוקרוס, ראלי, ראלי רייד, ראלי ספרינט, סופרבייק, סופרמוטו, ריצה, טרקטורונים
# type: "ספיישל טסט"
# ספיישל טסט, היירסקרמבל
place: "בקעת הירדן"
season: "2016"
# noseason: "true"
round: "מרוץ 1"
categories: [results, enduro]
# allmountain baja enduro gymkhana karting motocross rally rallysprint superbike supermoto running atv
# permalink: /results/enduro/2015/enduro2015r2.html
---

<!--<br><p class=message style="color: #333;">לתשומת לבכם: ההקפות מופיעות בסדר הפוך, כך שהקפה 1 היא ההקפה האחרונה, הקפה 2 היא ההקפה הלפני אחרונה וכך הלאה.</p>-->


<!--  טבלה -->



<!--  סוף טבלה   -->
