#!/bin/bash
cd $HOME/tnuatiming.github.io
git add -A && git commit -m "# upload from local #" && git push -u origin master

